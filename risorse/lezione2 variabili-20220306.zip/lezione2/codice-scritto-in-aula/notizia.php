<h3>Art. 3</h3>
Tutti i cittadini hanno pari dignità sociale e sono eguali davanti alla legge,
 senza distinzione di sesso, di razza, di lingua, di religione, di opinioni politiche, 
 di condizioni personali e sociali.<br>
È compito della Repubblica rimuovere gli ostacoli di ordine economico e sociale, che, limitando di fatto la libertà e l'eguaglianza dei cittadini, impediscono il pieno sviluppo della persona umana e l'effettiva partecipazione di tutti i lavoratori all'organizzazione politica, economica e sociale del Paese.
<br>

<?php
echo "TESTO redatto da Roberto Ruffinengo";

?>