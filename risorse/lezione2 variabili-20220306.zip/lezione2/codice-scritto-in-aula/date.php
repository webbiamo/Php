<b>anno corrente: <?php echo date('Y') ?> </b>

<br>

<?php
// la riga di codice deve sempre essere terminata da ;
// a meno che sia l'ultima riga prima della chiusura dei tag 

?>

<b>anno corrente: <?php echo date('Y');  ?> </b>

<br>
<?php // esiste una forma "corta" per fare echo:
// invece di scrivere    <?php echo si scrive <?= 
?>
<b>anno corrente: <?=  date('Y')  ?> </b>



