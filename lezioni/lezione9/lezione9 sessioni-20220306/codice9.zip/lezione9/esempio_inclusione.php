<?php
include_once('functions.php');
include('mie_funzioni.php');

require('intestazione.html');




echo "<br>corpo del file php<br>";

stampa();

include('piedino.html');



