<?php

include_once('functions.php');


function saluti(){
    echo "saluti";
}