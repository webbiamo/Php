come includere codice nei nostri file

il costrutto 

include('filename');  // se non trova il file genera un errore WARNING

require('filaneme');  // se nno trova il file genera un errore FATAL

include_once();
require_once();





