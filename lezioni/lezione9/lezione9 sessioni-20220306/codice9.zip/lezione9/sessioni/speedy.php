<?php
session_start();


echo "sono super veloce";
