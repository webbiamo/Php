<?php

session_start();
/* usa i dati di sessione e li modifica */

//$_SESSION['count']++;

$var=$_SESSION;



session_commit();

sleep(20);
echo "ho finito";
