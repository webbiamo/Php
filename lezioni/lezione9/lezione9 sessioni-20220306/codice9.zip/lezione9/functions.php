<?php

function stampa(){
    echo "benvenuti!";
}